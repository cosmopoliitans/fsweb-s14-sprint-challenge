'use strict'

const Schema = use('Schema')

class ProjectResourcesSchema extends Schema {
  up () {
    this.create('project_resources', (table) => {
      table.bigIncrements('project_resource_id')
      table.bigInteger('project_id').notNullable()
      table.bigInteger('resource_id').notNullable()
    })
  }

  down () {
    this.drop('project_resources')
  }
}

module.exports = ProjectResourcesSchema
