'use strict'

const Schema = use('Schema')

class ProjectsSchema extends Schema {
  up () {
    this.create('projects', (table) => {
      table.bigIncrements('project_id')
      table.string('project_name').notNullable()
      table.string('project_description')
      table.boolean('project_completed').notNullable().defaultTo(false)
    })
  }

  down () {
    this.drop('projects')
  }
}

module.exports = ProjectsSchema
