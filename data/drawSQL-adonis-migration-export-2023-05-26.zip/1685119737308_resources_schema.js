'use strict'

const Schema = use('Schema')

class ResourcesSchema extends Schema {
  up () {
    this.create('resources', (table) => {
      table.bigIncrements('resources_id')
      table.string('resources_name').unique().notNullable()
      table.string('resources_description')
    })
  }

  down () {
    this.drop('resources')
  }
}

module.exports = ResourcesSchema
