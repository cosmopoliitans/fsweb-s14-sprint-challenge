'use strict'

const Schema = use('Schema')

class TasksSchema extends Schema {
  up () {
    this.create('tasks', (table) => {
      table.bigIncrements('task_id')
      table.string('task_description').notNullable()
      table.string('task_notes')
      table.boolean('task_completed').notNullable().defaultTo(false)
      table.bigInteger('project_id').notNullable()
    })
  }

  down () {
    this.drop('tasks')
  }
}

module.exports = TasksSchema
